# TermiAI-Nexus — Obsidian UI Redesign

Visual reference: Obsidian dark surfaces, Electric Violet accents, translucent glass panels, Material 3 controls, rounded cards, and animated page transitions.

The current `integration/aram-ai-engine` branch already contains ten design source files identical to this reference package. Its Assistant and Aram AI Engine Center screens have newer revisions; the current-branch installer validates and preserves those revisions rather than overwriting their added behavior with older snapshots.

The 3D office keeps its existing geometry and interactions and uses the redesign palette. The package's installer is intentionally limited to the UI surface files and does not rewrite the AI gateway, coordinator, secure storage, PTY bridge, Android engine lifecycle, or GitHub service.

The installer does not run Flutter analysis, tests, or APK builds. Those checks must be run separately in the target Termux project.
