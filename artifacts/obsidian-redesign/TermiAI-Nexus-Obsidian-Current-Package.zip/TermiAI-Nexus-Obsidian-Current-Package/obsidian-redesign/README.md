# TermiAI-Nexus — Obsidian Redesign / Current Branch Package

This package preserves the original Obsidian + Electric Violet Flutter UI reference and includes a Termux installer adapted to the current `integration/aram-ai-engine` branch.

## What the installer does

- Reapplies the ten visual source files that are byte-for-byte identical to the current design reference.
- Verifies the current Assistant screen and preserves its newer conversation persistence and chat/project classification logic.
- Verifies the current Aram AI Engine Center and preserves its newer `modelAvailable`, GGUF import, and model download handling.
- Verifies the Obsidian/Violet palette in the existing 3D office widget.
- Creates a timestamped backup before copying the ten design files.
- Does not stage, commit, push, merge, or run a build.

## Important compatibility note

The original archive's `assistant_screen.dart` and `engine_center_screen.dart` are older snapshots. They are intentionally kept under `legacy-reference/` and are **not** installed. Installing those two old snapshots over the current branch would discard newer application behavior. The current project versions retain the design components and layout while preserving the later functionality.

## Apply from Termux

Extract this archive, then run from the repository root:

```bash
bash /path/to/obsidian-redesign/APPLY_FOR_CURRENT_BRANCH.sh "$PWD"
```

The script requires the `integration/aram-ai-engine` branch and exact current file baselines. It aborts before modifying anything if the branch, local files, or protected newer screens differ from the reviewed state.

## Validation status

The design source files were compared against the current GitHub branch. Ten source files have exact matching Git blob hashes. The assistant and engine screens have newer project revisions and are deliberately preserved. The current 3D office already contains the palette values from the redesign patch.

This package does not claim that Flutter analysis, APK compilation, emulator rendering, or on-device visual comparison was performed.
